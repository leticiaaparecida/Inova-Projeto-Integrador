<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<link rel="stylesheet" type="text/css" href="css/mapa.css">
        <link rel="icon" href="img/icon.jpg">

        <!--  FONT AWESOME -->
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">

        <!-- GOOGLE FONTS -->
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		
 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">
 	    <link rel="stylesheet" href="css/custom.css">

 		</head>

 	<body>

 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
                    <li > <a  href="mapa.php">Mapa</a></li>
                    <li > <a  href="agenda.php">Agenda</a></li>
                    <li > <a  href="horarios.php">Horários</a></li>
                    <li > <a  href="conta.php">Conta</a></li>
                    <li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

        <section class="container bg-azul info ">
            <div>
            <h4> Procure sua melhor rota!</h4>
            </div>
            <img src="img/mapa.jpg" class="radius">
        </section>

        
    <article class="bg-cinza">


        <section class=" map container">
        <div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3">
        <div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div>
        <script>
        (function () {
        var setting = {"height":400,"width":600,"zoom":15,"queryString":"Bragança Paulista, SP, Brasil","place_id":"ChIJFzt3ILfLzpQR1KK6w_WVAmc","satellite":true,"centerCoord":[-22.92909701211017,-46.56277485855464],"cid":"0x670295f5c3baa2d4","lang":"pt","cityUrl":"/brazil/braganca-paulista-57361","cityAnchorText":"","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"536819"};
        var d = document;
        var s = d.createElement('script');
        s.src = 'https://1map.com/js/script-for-user.js?embed_id=536819';
        s.async = true;
        s.onload = function (e) {
          window.OneMap.initMap(setting)
        };
        var to = d.getElementsByTagName('script')[0];
        to.parentNode.insertBefore(s, to);
        })();
        </script>
        <a href="https://1map.com/pt/map-embed">1 Map</a>
        </div>
        </section>

        <section class="busca container ">

            <form>
                
                <input type="search" class="bg-azul radius" name="partida" placeholder="Ponto de partida">
                <input type="search" row="2" class="bg-azul radius" name="destino" placeholder="Destino"><br>
                <button class="bg-laranja radius">Buscar</button>
            </form>
            
        </section>
    </article>




        <!--          RODAPÉ        -->

        <footer class="rodape container bg-gradient">
            
            <div class="icones-social">
                
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-google"></i></a>
                <a href="#"><i class="fa fa-envelope"></i></a>
            </div>

            <p class="copyright"> Copyright @ Inova Bragancity 2021. Todos os direitos reservados.</p>
        </footer>

        <!--          JQUERY        -->
    
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

        <!--    MATERIALIZE JS    -->
        <script src="js/materialize.min.js"></script>

    
        <script>

        /*         ABRIR E FECHAR MENU       */
        $(".btn-menu").click(function(){
            $(".menu").show();
        });

        $(".btn-close").click(function(){
            $(".menu").hide();
        });


        let time = 5000,
        currentImageIndex = 0,
        images = document
                .querySelectorAll("#slider img")
        max = images.length;

        function nextImage() {

        images[currentImageIndex]
        .classList.remove("selected")

        currentImageIndex++

        if(currentImageIndex >= max)
        currentImageIndex = 0

         images[currentImageIndex]
        .classList.add("selected") }

        function start() {
        setInterval(() => {
        // troca de image
        nextImage() }, time) }
        window.addEventListener("load", start)


    </script>
    
    </body>

    </html>