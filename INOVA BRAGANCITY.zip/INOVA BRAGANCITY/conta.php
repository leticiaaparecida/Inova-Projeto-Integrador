<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<link rel="stylesheet" type="text/css" href="css/conta.css">
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		<link rel="icon" href="img/icon.jpg">

 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">
 	    <link rel="stylesheet" href="css/custom.css">

 		</head>

 	<body>

 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
                    <li > <a  href="mapa.php">Mapa</a></li>
                    <li > <a  href="agenda.php">Agenda</a></li>
                    <li > <a  href="horarios.php">Horários</a></li>
                    <li > <a  href="conta.php">Conta</a></li>
                    <li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

 		<!--     FORMULARIO DE CADASTRO    -->

 		<section class=" formulario  container bg-azul col s8 m8 l8" >

 			<h2>Cadastre-se ou faça login agora!</h2>
 			<h3> Mantenha suas informações salvas!</h3>


 		    <form name="cadastro" action="php/cadastro.php" method="POST">
                <h2 style="margin-bottom: 20px;"> Cadastro</h2>
                <input type="text" class="bg-cinza radius" name="nome" placeholder="Seu nome">
 		    	<input type="email" class="bg-cinza radius" name="email" placeholder="Seu email">
 				<input type="password" class="bg-cinza radius" name="senha" placeholder="Sua senha">
 				<button class="bg-white radius cadastro" name="enviar"> Cadastrar</button>
 			</form>


            <form name="login" action="php/login.php" method="POST">
                <h2 style="margin-bottom: 20px;"> Login</h2>
                <input type="email" class="bg-azul radius" name="email" placeholder="Seu email">
                <input type="password" class="bg-azul radius" name="senha" placeholder="Sua senha">
                <button class="bg-laranja radius cadastro" name="entrar"> Login</button>
            </form>



 			
        </section>
 		
        <main class=" container sobre">
            <h1 class="laranja">Conheça o Projeto e as Desenvolvedoras</h1>

 			<div  id="slider"class="desenvolvedoras .radius">
                <img src="img/leticia.jpg" class="selected" alt="img1">
                <img src="img/vitoria.jpg" alt="img2">
            </div>

 			</div>
            
 			<div class="projeto">
 				<h2 class="azul">Olá! Nós somos as desenvolvedoras do Inova Bragancity!</h2>
                <h5>Letícia Santos e Vitória Campos.</h5>
            </br>
                <p>O Inova Bragancity surgiu como uma forma de facilitar a vida dos estudantes que se deslocam até a escola por meio do transporte público.</p>
                <p>Eu, Letícia e minha amiga Vitória, moramos em uma cidade a 25km do Instituto de Ciência e Tecnologia de São Paulo - Câmpus Bragança Paulista.</p>
                <p> Quando iniciamos nossos estudos nessa instituição, encontramos diversos problemas ligados a falta de transporte, atrasos, horários diferentes e um serviço que facilitasse a reposição de créditos para continuarmos viajanto tranquilamente.</p>
                <p>Com o intuito de ajudarmos nossos amigos, estudantes e também a população usuária de transporte público, criamos o Inova Bragancity! :)</p>
 			</div>

 		</main>
 		

 		<!--          RODAPÉ        -->

 		<footer class="rodape container bg-gradient">
 			
 			<div class="icones-social">
 				
 				<a href="#"><i class="fa fa-facebook"></i></a>
 				<a href="#"><i class="fa fa-twitter"></i></a>
 				<a href="#"><i class="fa fa-instagram"></i></a>
 				<a href="#"><i class="fa fa-google"></i></a>
 				<a href="#"><i class="fa fa-envelope"></i></a>
 			</div>

 			<p class="copyright"> Copyright @ Inova Bragancity 2021. Todos os direitos reservados.</p>
 		</footer>

 		<!--          JQUERY        -->
 	
 	    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

 	    <!--    MATERIALIZE JS    -->
 		<script src="js/materialize.min.js"></script>

 	
 	    <script>

        /*         ABRIR E FECHAR MENU       */
 		$(".btn-menu").click(function(){
 			$(".menu").show();
 		});

 		$(".btn-close").click(function(){
 			$(".menu").hide();
 		});


        let time = 5000,
        currentImageIndex = 0,
        images = document
                .querySelectorAll("#slider img")
        max = images.length;

        function nextImage() {

        images[currentImageIndex]
        .classList.remove("selected")

        currentImageIndex++

        if(currentImageIndex >= max)
        currentImageIndex = 0

         images[currentImageIndex]
        .classList.add("selected") }

        function start() {
        setInterval(() => {
        // troca de imagem
        nextImage() }, time) }
        window.addEventListener("load", start)


 	</script>
 	
 	</body>

 	</html>