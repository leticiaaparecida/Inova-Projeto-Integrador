<?php
//Conexão
require_once 'php/connect.php';

//Sessão
session_start();

//Verificação
if (!isset($_SESSION['logado'])) :
	header('Location: conta.php');
endif;
	

//dados
$id = $_SESSION['id_usuario'];
$sql = "SELECT * FROM usuarios WHERE id = '$id' ";
$resultado = mysqli_query($conexao, $sql);
$dados = mysqli_fetch_array($resultado);
mysqli_close($conexao);

?>

<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		<link rel="icon" href="img/icon.jpg">
 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">


 	</head>

 	<body>

 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
 					<li > <a  href="mapa.php">Mapa</a></li>
 					<li > <a  href="agenda.php">Agenda</a></li>
 					<li > <a  href="horarios.php">Horários</a></li>
 					<li > <a  href="conta.php">Conta</a></li>
 					<li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

 		<h1 class=" container bg-azul" style="font-size:2em; text-align: center;">Seja bem vindo(a) <?php echo $dados['nome']; ?>!</h1>

	<a href="php/logout.php" class="bg-laranja" style="font-size: 1.5em; margin-left: 30px;">Sair</a>

</body>
</html>