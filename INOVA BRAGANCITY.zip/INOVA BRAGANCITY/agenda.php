<?php
require_once'php/classeeventos.php';
$p = new Eventos("inova", "localhost","root","");
?>
<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<link rel="stylesheet" type="text/css" href="css/agenda.css">
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		<link rel="icon" href="img/icon.jpg">
 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">


 	</head>

 	<body>

        <?php 
    if(isset($_POST['titulo'])) //CLICOU NO BOTÃO CADASTRAR OU EDITAR
    {
        if(isset($_GET['id_up']) && !empty($_GET['id_up'])){

            $id_upd = addslashes($_GET['id_up']);

            $titulo = addslashes($_POST['titulo']);
            $evento = addslashes($_POST['evento']);
            $data = addslashes($_POST['data']);

            if (!empty($titulo) && !empty($evento) && !empty($data)) {
               
                //EDITAR
                $p->atualizarEvento($id_upd,$titulo,$evento,$data);
                header('Location: agenda.php');

           } 
           else{

                ?>
                <div class="aviso">
                <img src="aviso.jpg">
                <h4>Preencha todos os campos </h4>
                </div>
                <?php 
            }

        }
        //--------------------------CADASTRAR------------------------
        else
        {
            $titulo = addslashes($_POST['titulo']);
            $evento = addslashes($_POST['evento']);
            $data = addslashes($_POST['data']);

            if (!empty($titulo) && !empty($evento) && !empty($data)) {
                //cadastrar
                if(!$p->cadastrarEvento($titulo,$evento,$data)){
                ?>
                <div class="aviso">
                <img src="aviso.jpg">
                <h4>Email já está cadastrado </h4>
                </div>
                <?php 
                }
           } 
           else{

                ?>
                <div class="aviso">
                <img src="aviso.jpg">
                <h4>Preencha todos os campos </h4>
                </div>
                <?php 
                
            }

        }
    }
?>

<?php

    if(isset($_GET['id_up']))//SE A PESSOA CLICOU NO BOTÃO EDITAR
    {
        $id_update = addslashes($_GET['id_up']);
        $res = $p->buscarDadosEvento($id_update);
    }

?>
 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
                    <li > <a  href="mapa.php">Mapa</a></li>
                    <li > <a  href="agenda.php">Agenda</a></li>
                    <li > <a  href="horarios.php">Horários</a></li>
                    <li > <a  href="conta.php">Conta</a></li>
                    <li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

 		<!-- INFORMAÇÃO SOBRE A PÁGINA -->

 		<section class="container bg-azul agenda ">
 			<div>
 			<h4> Organize seus compromissos de uma forma rápida e prática!</h4>
 			<br/>
 			<p> Criamos esse ambiente especialmente para a correria do dia a dia. 
 			Sabemos o quão doida pode ser uma rotina cheia de afazeres, por isso resolvemos facilitar para nossos usuários.
 			</p>
 		    </div>
 			<img src="img/agendaa.jpg" class="radius">
 		</section>


       <!-- ÁREA PARA FAZER AS ANOTAÇÕES -->

       <section class=" bg-white container agenda" >

        <div class="bg-laranja eventos radius">

                <h2 > Não esqueça de seus eventos!</h2><br>

            <form action="" method="POST">
                <input type="date" class="bg-laranja radius" name="data" value="<?php if(isset($res)){ echo $res['data'];} ?>"><br>
                <input type="text" class="bg-laranja radius" name="titulo" value="<?php if(isset($res)){ echo $res['titulo'];} ?>" placeholder="Título"><br>
                <textarea style="width: 100%;" type="text" row="2" class="bg-laranja radius" name="evento" value="<?php if(isset($res)){ echo $res['evento'];} ?>" placeholder="Evento"></textarea><br><br>
                <input type="submit" class="bg-black radius" value="<?php if(isset($res)){ echo "Atualizar";} else{ echo "Salvar";} ?>">
            </form>
        </div>

        <div class=" bg-azul radius eventos2">

            <h1 > Seus eventos</h1><br>

            <table id="tabela">
                <tr>
                    <td>DATA</td>
                    <td >TÍTULO</td>
                    <td>EVENTO</td>
                    <td> AÇÃO</td>
                </tr>
        <?php

        $dados = $p->buscarDados();

        if (count($dados) > 0) //TEM EVENTOS NO BANCO DE DADOS
         {
            for ($i=0; $i < count($dados) ; $i++) {
                echo "<tr>";             
                foreach ($dados[$i] as $k => $v) {
                    if ($k != "id") {
                        echo "<td>".$v."</td>";  
                    }
                }
            ?>  
                <td>
                    <a id="botao" href="agenda.php?id_up=<?php echo $dados[$i]['id']; //para editar pelo id  ?>">Editar</a>
                    <a id="botao" href="agenda.php?id=<?php echo $dados[$i]['id']; //para excluir pelo id  ?>">Excluir</a> 
                </td>
            <?php
            
            echo "</tr>";
            }
        }
        else //O BANCO DE DADOS ESTA VAZIO
        {

        ?>
        </table>

            <div class="aviso">
                <li>Ainda não há eventos cadastrados </li>
            </div>
            <?php }
        ?>
    </div>

    </section>
 

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="http://momentjs.com/downloads/moment.js"></script>
    <link rel='stylesheet' href='//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.6.1/fullcalendar.min.css' />
    <script src='//cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.6.1/fullcalendar.min.js'></script>

 	<!--          JQUERY        -->
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

 	<!--    MATERIALIZE JS    -->
 	<script src="js/materialize.min.js"></script>


 	<!--         ABRIR E FECHAR MENU        -->
 	<script>
 		$(".btn-menu").click(function(){
 			$(".menu").show();
 		});

 		$(".btn-close").click(function(){
 			$(".menu").hide();
 		});

 	</script>
 	
 	</body>

 	</html>

    <?php
if (isset($_GET['id'])) 
    {
        //para excluir evento
        $id_evento = addslashes($_GET['id']);
        $p->excluirEvento($id_evento);
    }
?>

    