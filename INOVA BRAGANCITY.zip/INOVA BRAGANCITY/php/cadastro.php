<?php

include_once 'connect.php';
date_default_timezone_set('America/Sao_Paulo');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];


$msg_contato = "INSERT INTO usuarios (nome, email, senha) VALUES('$nome', '$email', '$senha')";

$result= mysqli_query($conexao, $msg_contato);
echo "<meta http-equiv='refresh' content='10;URL=../conta.php'>";

?>