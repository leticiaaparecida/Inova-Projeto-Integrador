<?php
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "inova";

$conexao = mysqli_connect($host, $user,$pass, $dbname);

