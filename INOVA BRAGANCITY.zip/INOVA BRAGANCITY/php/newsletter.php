<?php 

include_once 'connect.php';
date_default_timezone_set('America/Sao_Paulo');

$nome = $_POST['nome'];
$email = $_POST['email'];
$data = date('d/m/Y H:i:s');

$msg_news = "INSERT INTO newsletter (nome, email,created) VALUES('$nome', '$email',NOW())";

$result= mysqli_query($conexao, $msg_news);

require_once('src/PHPMailer.php');
require_once('src/SMTP.php');
require_once('src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'vitoriaapcampos13@gmail.com';
  $mail->Password = 'ppsboferffrffwxk';
  $mail->Port = 587;
 
  $mail->setFrom('vitoriaapcampos13@gmail.com');
  $mail->addAddress($email);
 
  $mail->isHTML(true);
  $mail->Subject = 'Novidades do Inova Bragancity :)';
  $mail->Body = "Olá {$nome}!<br>
           Seja Bem vindo(a) ao Inova Bragancity!<br>
           Estamos felizes em ter você aqui :)<br>
           Sempre que houver novidades enviaremos nesse email que voce cadastrou!<br>
           Até breve.<br><br>
           Equipe Inova Bragancity.<br>
           Data/hora: {$data}";
 
  if($mail->send()) {
    echo 'Email enviado com sucesso.';
  } else {
    echo 'Email não enviado.';
  }
  echo "<meta http-equiv='refresh' content='10;URL=../index.php'>";

?>