<?php

Class Eventos{

	private $pdo;
	//construtor
	//conexao com o banco de dados
	public function __construct($dbname, $host, $user, $pass){

		try{
		$this->pdo = new PDO("mysql:dbname=".$dbname.";host=".$host,$user,$pass); //concatenação

		}
		catch(PDOException $e){
			echo "Erro com banco de dados: ".$e->getMessage();
			exit();
		}
		catch(Exception $e){
			echo "Erro genérico: ".$e->getMessage();
			exit();
		}
		
	}

//FUNCAO PARA BUSCAR DADOS E COLOCAR NA DIREITA DA TELA

	public function buscarDados(){
		$res = array();
		$cmd = $this->pdo->query("SELECT * FROM agenda ORDER BY data");
		$res = $cmd->fetchAll(PDO::FETCH_ASSOC);
		return $res;
	}


//FUNCAO PARA CADASTRAR EVENTO NO BANCO DE DADOS
    public function cadastrarEvento($titulo,$evento,$data){

    	//ANTES DE CADASTRAR VERIFICAR SE JÁ NÃO ESTÁ COM O TITULO CADASTRADO
    	$cmd = $this->pdo->prepare("SELECT id from agenda WHERE titulo = :t");
    	$cmd->bindValue(":t",$titulo);
    	$cmd->execute();

    	if($cmd->rowCount()>0){
    		//titulo já existe
    		return false;
    	} else {
    		//não foi encontrado
    		$cmd= $this->pdo->prepare("INSERT INTO agenda (titulo, evento,data) VALUES (:t, :e, :d)");
    		$cmd->bindValue(":t",$titulo);
    		$cmd->bindValue(":e",$evento);
    		$cmd->bindValue(":d",$data);
    		$cmd->execute();
    		return true;
    	}
    }


    //FUNCAO PARA EXCLUIR EVENTO

    public function excluirEvento($id){

    	$cmd = $this->pdo->prepare("DELETE FROM agenda WHERE id = :id");
    	$cmd->bindValue(":id",$id);
    	$cmd->execute();

    }

    //BUSCAR DADOS DE UM EVENTO

    public function buscarDadosEvento($id){

    	$res = array();

    	$cmd = $this->pdo->prepare("SELECT * FROM agenda WHERE id = :id");
    	$cmd->bindValue(":id",$id);
    	$cmd->execute();

    	$res = $cmd->fetch(PDO::FETCH_ASSOC);
    	return $res;
    }

    //ATUALIZAR DADOS DO BANCO DE DADOS

    public function atualizarEvento ($id, $titulo, $evento, $data){
    	
    		
    	$cmd = $this->pdo->prepare("UPDATE agenda SET titulo = :t, evento= :e, data = :d WHERE id= :id");
    	$cmd->bindValue(":t",$titulo);
    	$cmd->bindValue(":e",$evento);
    	$cmd->bindValue(":d",$data);
    	$cmd->bindValue(":id",$id);
    	$cmd->execute();
    	
        }






}

?>