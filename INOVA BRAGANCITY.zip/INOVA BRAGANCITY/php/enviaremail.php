<?php

include_once 'connect.php';
date_default_timezone_set('America/Sao_Paulo');

$nome = $_POST['nome'];
$email = $_POST['email'];
$assunto = $_POST['assunto'];
$mensagem = $_POST['mensagem'];
$data = date('d/m/Y H:i:s');


$msg_contato = "INSERT INTO sugestao (nome, email, assunto, mensagem, created) VALUES('$nome', '$email', '$assunto', '$mensagem', NOW())";

$result= mysqli_query($conexao, $msg_contato);

require_once('src/PHPMailer.php');
require_once('src/SMTP.php');
require_once('src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

$mail = new PHPMailer();
  $mail->isSMTP();
  $mail->Host = 'smtp.gmail.com';
  $mail->SMTPAuth = true;
  $mail->Username = 'la786325@gmail.com';
  $mail->Password = 'iieflwmdqjltvlwk';
  $mail->Port = 587;
 
  $mail->setFrom('la786325@gmail.com');
  $mail->addAddress('la786325@gmail.com');
 
  $mail->isHTML(true);
  $mail->Subject = $assunto;
  $mail->Body = "Nome: {$nome}<br>
           Email: {$email}<br>
           Assunto: {$assunto}<br>
           Mensagem: {$mensagem}<br>
           Data/hora: {$data}";
 
  if($mail->send()) {
    echo 'Email enviado com sucesso.';
  } else {
    echo 'Email não enviado.';
  }


 $mail2 = new PHPMailer();
  $mail2->isSMTP();
  $mail2->Host = 'smtp.gmail.com';
  $mail2->SMTPAuth = true;
  $mail2->Username = 'vitoriaapcampos13@gmail.com';
  $mail2->Password = 'ppsboferffrffwxk';
  $mail2->Port = 587;
 
  $mail2->setFrom('vitoriaapcampos13@gmail.com');
  $mail2->addAddress('vitoriaapcampos13@gmail.com');
 
  $mail2->isHTML(true);
  $mail2->Subject = $assunto;
  $mail2->Body = "Nome: {$nome}<br>
           Email: {$email}<br>
           Assunto: {$assunto}<br>
           Mensagem: {$mensagem}<br>
           Data/hora: {$data}";
 
  if($mail2->send()) {
    echo 'Email enviado com sucesso.';
  } else {
    echo 'Email não enviado.';
  }

  $mail3 = new PHPMailer();
  $mail3->isSMTP();
  $mail3->Host = 'smtp.gmail.com';
  $mail3->SMTPAuth = true;
  $mail3->Username = 'vitoriaapcampos13@gmail.com';
  $mail3->Password = 'ppsboferffrffwxk';
  $mail3->Port = 587;
 
  $mail3->setFrom('vitoriaapcampos13@gmail.com');
  $mail3->addAddress($email);
 
  $mail3->isHTML(true);
  $mail3->Subject = $assunto;
  $mail3->Body = "Olá, em breve retornaremos sua mensagem! Obrigada pela colaboração!<br> <br>
  Equipe Bragancity a sua disposição.<br><br>
  Assunto: ".$assunto."<br>Data: ".$data;
 
  if($mail3->send()) {
    echo 'Email enviado com sucesso.';
  } else {
    echo '<br/> Email não enviado.';
  }

echo "<meta http-equiv='refresh' content='10;URL=../contato.php'>";


?>