<?php
//conexão
require_once 'connect.php';

//sessão
session_start();

//botao enviar
if (isset($_POST['entrar'])) :
	$erros = array();
	$email = mysqli_escape_string($conexao, $_POST['email']);
	$senha = mysqli_escape_string($conexao, $_POST['senha']);

	 if (empty($email) or empty($senha)) :
	 	$erros[] = "<li> O campo login/senha precisa ser preenchido </li>";
	 else:
	 	$sql = "SELECT email FROM usuarios WHERE email = '$email' ";
	 	$resultado = mysqli_query($conexao, $sql);

	 	if (mysqli_num_rows($resultado) > 0) :
	 		$senha = $senha;

	 		$sql = "SELECT * FROM usuarios WHERE email = '$email' AND senha = '$senha' ";
	 		$resultado = mysqli_query($conexao, $sql);

	 		  if (mysqli_num_rows($resultado) == 1) :
	 		  	$dados = mysqli_fetch_array($resultado);
	 		  	mysqli_close($conexao);
	 		  	$_SESSION['logado'] = true;
	 		  	$_SESSION['id_usuario'] = $dados['id'];
	 		  	header('Location: ../restrito.php');

	 		  else:
	 		  	$erros[] = "<li> Usuário e senha não conferem </li>";

	 		  endif;

	 		  	
	 	else:
	 		$erros[] = "<li> Usuário inexistente </li>";
	 	endif;

	 endif;

endif;



	if (!empty($erros)) :
		foreach ($erros as $erro) :
			echo $erro;
		endforeach;
	endif;
	
?>