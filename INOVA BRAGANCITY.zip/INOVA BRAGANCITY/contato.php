<?php
session_start();

?>

<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<link rel="stylesheet" type="text/css" href="css/contato.css">
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		<link rel="icon" href="img/icon.jpg">
 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">


 	</head>

 	<body>

 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
 					<li > <a  href="mapa.php">Mapa</a></li>
 					<li > <a  href="agenda.php">Agenda</a></li>
 					<li > <a  href="horarios.php">Horários</a></li>
 					<li > <a  href="conta.php">Conta</a></li>
 					<li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

 		<section class="container bg-azul info ">
 			<div id="um">
 			<h4> Entre em contato conosco!</h4>
 			<br/>
 			<h4> Quer deixar uma opinião? Responda o formulário abaixo!</h4>
 		   </div>
 		   <div id="dois"><p> Email: InovaBragancity@gmail.com</p><br>
 			<p> Telefone: 40156784</p><br>
 			<p> Redes sociais: Inova Bragancity</p><br></div>
 		</section>

 		<!--     OPINIÃO   -->

 		<section class="opiniao container bg-black">

 			
 			<form action="php/enviaremail.php"  method="POST">
 				
 				<input type="text" class="bg-black radius" name="nome" placeholder="Seu nome" required>
 				<input type="email" class="bg-black radius" name="email" placeholder="Seu email" required>
 				<input type="text" class="bg-black radius" name="assunto" placeholder="Assunto" required>
 				<textarea type="text" row="5" class="bg-black radius" name="mensagem" placeholder="Mensagem" required></textarea><br>
 				<button class="bg-white radius" type="submit" name="SendAddMsg"> Enviar</button>
 			</form>
 			
 		</section>


 		<!--          RODAPÉ        -->

 		<footer class="rodape container bg-gradient">
 			
 			<div class="icones-social">
 				
 				<a href="#"><i class="fa fa-facebook"></i></a>
 				<a href="#"><i class="fa fa-twitter"></i></a>
 				<a href="#"><i class="fa fa-instagram"></i></a>
 				<a href="#"><i class="fa fa-google"></i></a>
 				<a href="#"><i class="fa fa-envelope"></i></a>
 			</div>

 			<p class="copyright"> Copyright @ Inova Bragancity 2021. Todos os direitos reservados.</p>
 		</footer>

 		<!--          JQUERY        -->
 	
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 	<!--    MATERIALIZE JS    -->
 		<script src="js/materialize.min.js"></script>

 	<!--         ABRIR E FECHAR MENU        -->
 	<script>
 		$(".btn-menu").click(function(){
 			$(".menu").show();
 		});

 		$(".btn-close").click(function(){
 			$(".menu").hide();
 		});

 	</script>
 	</body>

 	</html>