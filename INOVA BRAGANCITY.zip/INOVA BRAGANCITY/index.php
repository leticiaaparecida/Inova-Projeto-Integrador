


<!DOCTYPE html>

 	<html lang="pt-br">

 	<head>

 		<!--          LINKS ANEXADOS        -->

 		<meta charset="utf-8">
 		<meta name="viewport" content="width=device-width, initial-scale=1">
 		<title> Inova Bragancity</title>
 		<link rel="stylesheet" type="text/css" href="css/estilo.css">
 		<script src="https://kit.fontawesome.com/5bd800b14c.js" crossorigin="anonymous"></script>
 		<link rel="preconnect" href="https://fonts.gstatic.com">
 		<link href="https://fonts.googleapis.com/css2?family=Stint+Ultra+Condensed&display=swap" rel="stylesheet">
 		<link rel="icon" href="img/icon.jpg">
 		<!--MATERIALIZE CSS-->
 	    <link rel="stylesheet" href="css/materialize.min.css">


 	</head>

 	<body>

 		<!--          CABEÇALHO E MENU        -->

 		<header class="cabecalho container">
 			
 			<a href="index.html"><h1 class="logo"> Inova Bragancity</h1></a>
 			<button class="btn-menu "><i class="fas fa-bars fa-lg"></i></button>
 			<nav class="menu ">
 				<a class="btn-close"><i class="fa fa-times"></i></a>
 				<ul >
 					<li > <a  href="index.php">Home</a></li>
 					<li > <a  href="mapa.php">Mapa</a></li>
 					<li > <a  href="agenda.php">Agenda</a></li>
 					<li > <a  href="horarios.php">Horários</a></li>
 					<li > <a  href="conta.php">Conta</a></li>
 					<li > <a  href="contato.php">Contato</a></li>

 				</ul>
 			</nav>
 		</header>

 		<!--          BANNER E AFINS        -->

 		<div class="banner container">

 			<div class="titulo">
 				
 				<h2> Conheça o Inova Bragancity</h2>
 				<h3> Auxiliamos você no uso do transporte público! </h3>
 			</div> 

 			<div class="buttons">
 				<button class="btn btn-sobre bg-black radius"> <a href="conta.php">Sobre <i class="fa fa-question-circle"></i></a></button>
 			</div>			

 		</div>

 		<!--          CONTEÚDO DA PÁGINA INICIAL LIGANDO AS OUTRAS PÁGINAS        -->

 		<main class="servicos container radius">

 			<article class="servico bg-white radius hoverable">
 				<a href="#"> <img src="img/agendaa.jpg" alt="Campanhas Publicitárias"> </a>
 				<div class="inner">
 					<a href="agenda.php">Agenda</a>
 					<h4>Anote seus compromissos!</h4>
 					<p> Segunda-Domingo</p>
 				</div>
 			</article>

 			<article class="servico bg-white radius">
 				<a href="mapa.php"> <img src="img/mapa.jpg" alt="Acessar Mapa"> </a>
 				<div class="inner">
 					<a href="mapa.php">Mapa</a>
 					<h4>Melhor linha para seu trajeto!</h4>
 					<p> Ponto de partida - Destino</p>
 				</div>
 			</article>

 			<article class="servico bg-white radius">
 				<a href="#"> <img src="img/contato.jpg" alt="Fale Conosco"> </a>
 				<div class="inner">
 					<a href="contato.php">Fale Conosco</a>
 					<h4>Queremos ouvir você!</h4>
 					<p> Conte-nos sua opinião sobre o Inova Bragancity </p>
 				</div>
 			</article>
 		</main>

 		<!--          CONTEÚDO DA PÁGINA INICIAL HORÁRIOS        -->

 		<section class=" horarios bg-azul"> <a href="#">Horários</a></section>
 			
 		<main class="servicos  container radius ">

 			<article class="servico bg-cinza radius">
 				<div class="inner2">
 					<a href="horarios.php"><i class="far fa-clock azul"> </i> Linha 215</a>
 					<h4>Tuiuti <i class="fas fa-angle-double-right laranja"></i> Bragança Paulista - via Passa três:</h4>
 					<p>Segunda à Sexta<p>
 					<p>Carro 467 </p>
 					<a href="#">ver mais</a>
 				</div>
 			</article>

 			<article class="servico bg-cinza radius">
 				<div class="inner2">
 					<a href="horarios.php"><i class="far fa-clock azul"> </i> Linha 210</a>
 					<h4>Tuiuti <i class="fas fa-angle-double-right laranja"></i> Bragança Paulista:</h4>
 					<p>Segunda à Sexta<p>
 					<p>Carro 469 </p>
 					<a href="#">ver mais</a>
 				</div>
 			</article>

 			<article class="servico bg-cinza radius">
 				<div class="inner2">
 					<a href="horarios.php"><i class="far fa-clock azul"> </i> Linha 698</a>
 					<h4>Tuiuti <i class="fas fa-angle-double-right laranja"></i> Morungaba:</h4>
 					<p>Segunda à Sexta<p>
 					<p>Carro 302 </p>
 					<a href="#">ver mais</a>
 				</div>
 			</article>
		

 		</main> 

 		<!--          NEWSLETTER        -->

 		<section class="newsletter container bg-black">

 			<h2>Inscreva-se agora!</h2>
 			<h3> Receba Novidades e muito mais!</h3>

 			<form action="php/newsletter.php" method="POST">
 				
 				<input type="text" class="bg-black radius" id="nome" name="nome" placeholder="Seu nome">
 				<input type="email" class="bg-black radius" id="email" name="email" placeholder="Seu email">
 				<button class="bg-white radius" value="enviar" type="submit" name="enviar"> Inscrever meu e-mail</button>
 			</form>
 			
 		</section>

 		<!--          RODAPÉ        -->

 		<footer class="rodape container bg-gradient">
 			
 			<div class="icones-social">
 				
 				<a href="#"><i class="fa fa-facebook"></i></a>
 				<a href="#"><i class="fa fa-twitter"></i></a>
 				<a href="#"><i class="fa fa-instagram"></i></a>
 				<a href="#"><i class="fa fa-google"></i></a>
 				<a href="#"><i class="fa fa-envelope"></i></a>
 			</div>

 			<p class="copyright"> Copyright @ Inova Bragancity 2021. Todos os direitos reservados.</p>
 		</footer>

 		<!--          JQUERY        -->
 	
 	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 	<!--    MATERIALIZE JS    -->
 		<script src="js/materialize.min.js"></script>

 	<!--         ABRIR E FECHAR MENU        -->
 	<script>
 		$(".btn-menu").click(function(){
 			$(".menu").show();
 		});

 		$(".btn-close").click(function(){
 			$(".menu").hide();
 		});

 	</script>
 	</body>

 	</html>